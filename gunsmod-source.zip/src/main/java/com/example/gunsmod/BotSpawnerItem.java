package com.example.gunsmod;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class BotSpawnerItem extends Item {
    private final boolean ally;

    public BotSpawnerItem(Item.Properties props, boolean ally) {
        super(props.stacksTo(16));
        this.ally = ally;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!(level instanceof ServerLevel sl)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        GunBotEntity bot = GunsMod.GUN_BOT.get().create(sl);
        if (bot == null) return InteractionResult.FAIL;
        float yaw = ctx.getRotation();
        bot.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, yaw, 0f);
        bot.setYHeadRot(yaw);
        Player p = ctx.getPlayer();
        bot.setAlly(ally, p == null ? null : p.getUUID());
        sl.addFreshEntity(bot);
        ctx.getItemInHand().consume(1, p);
        return InteractionResult.CONSUME;
    }
}
