package com.example.gunsmod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class GunCustomizerScreen extends AbstractContainerScreen<GunCustomizerMenu> {
    private static final String[] SCOPE_NAMES = {"No scope", "Red dot", "4x scope"};

    public GunCustomizerScreen(GunCustomizerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 256;
        this.imageHeight = 232;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int swatchX(int i) {
        return leftPos + 14 + i * 24;
    }

    private int swatchY() {
        return topPos + 93;
    }

    private int scopeX(int i) {
        return leftPos + 14 + i * 82;
    }

    private int scopeY() {
        return topPos + 120;
    }

    private void small(GuiGraphics g, String text, int x, int y, int color) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(0.7f, 0.7f, 1f);
        g.drawString(font, text, 0, 0, color, false);
        g.pose().popPose();
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos;
        g.fill(x - 2, y - 2, x + imageWidth + 2, y + imageHeight + 2, 0xFF000000);
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF2B2F36);
        g.fill(x, y, x + imageWidth, y + 22, 0xFF181B20);
        g.fill(x, y + 22, x + imageWidth, y + 24, 0xFF7C5CFF);
        g.drawString(font, "GUN CUSTOMIZER", x + 10, y + 8, 0xFFB9A6FF, false);

        for (Slot s : menu.slots) {
            g.fill(x + s.x - 1, y + s.y - 1, x + s.x + 17, y + s.y + 17, 0xFF111317);
            g.fill(x + s.x, y + s.y, x + s.x + 16, y + s.y + 16, 0xFF3A404A);
        }
        g.drawString(font, "Weapon", x + 8, y + 26, 0xFF8A919C, false);

        // preview
        g.fill(x + 40, y + 28, x + 250, y + 82, 0xFF1F2227);
        ItemStack gun = menu.getSlot(0).getItem();
        if (!gun.isEmpty()) {
            g.pose().pushPose();
            g.pose().translate(x + 40 + (210 - 48) / 2f, y + 31, 0);
            g.pose().scale(3f, 3f, 1f);
            g.renderItem(gun, 0, 0);
            g.pose().popPose();
        } else {
            g.drawString(font, "Put a weapon in the slot", x + 84, y + 51, 0xFF6C737E, false);
        }

        int curPaint = gun.getItem() instanceof GunItem ? GunItem.getPaint(gun) : -1;
        int curScope = gun.getItem() instanceof GunItem ? GunItem.getScope(gun) : -1;

        g.drawString(font, "PAINT", x + 14, y + 84, 0xFFE0A030, false);
        for (int i = 0; i < Paints.COUNT; i++) {
            int sx = swatchX(i), sy = swatchY();
            g.fill(sx - 1, sy - 1, sx + 17, sy + 15, i == curPaint ? 0xFFFFFFFF : 0xFF000000);
            g.fill(sx, sy, sx + 16, sy + 14, Paints.COLORS[i]);
        }

        g.drawString(font, "SCOPE", x + 14, y + 110, 0xFFE0A030, false);
        for (int i = 0; i < 3; i++) {
            int bx = scopeX(i), by = scopeY();
            boolean hov = mx >= bx && mx < bx + 76 && my >= by && my < by + 14;
            g.fill(bx - 1, by - 1, bx + 77, by + 15, i == curScope ? 0xFFFFFFFF : 0xFF000000);
            g.fill(bx, by, bx + 76, by + 14, hov ? 0xFF4C5460 : 0xFF3A404A);
            g.drawString(font, SCOPE_NAMES[i], bx + (76 - font.width(SCOPE_NAMES[i])) / 2, by + 3, 0xFFFFFFFF, false);
        }
        small(g, "2 iron + 1 redstone", scopeX(1) + 2, scopeY() + 17, 0xFF8A919C);
        small(g, "4 iron + 1 diamond", scopeX(2) + 2, scopeY() + 17, 0xFF8A919C);
        small(g, "Free", scopeX(0) + 2, scopeY() + 17, 0xFF8A919C);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        for (int i = 0; i < Paints.COUNT; i++) {
            int sx = swatchX(i), sy = swatchY();
            if (mx >= sx && mx < sx + 16 && my >= sy && my < sy + 14) {
                g.renderTooltip(font, Component.literal(Paints.NAMES[i]), mx, my);
            }
        }
        this.renderTooltip(g, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        boolean hasGun = menu.getSlot(0).getItem().getItem() instanceof GunItem;
        if (hasGun && minecraft != null && minecraft.gameMode != null) {
            for (int i = 0; i < Paints.COUNT; i++) {
                int sx = swatchX(i), sy = swatchY();
                if (mx >= sx && mx < sx + 16 && my >= sy && my < sy + 14) {
                    minecraft.gameMode.handleInventoryButtonClick(menu.containerId, i);
                    return true;
                }
            }
            for (int i = 0; i < 3; i++) {
                int bx = scopeX(i), by = scopeY();
                if (mx >= bx && mx < bx + 76 && my >= by && my < by + 14) {
                    minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 10 + i);
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
