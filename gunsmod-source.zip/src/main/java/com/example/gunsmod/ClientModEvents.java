package com.example.gunsmod;

import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = GunsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping RELOAD = new KeyMapping("key.gunsmod.reload", GLFW.GLFW_KEY_R, "key.categories.gunsmod");
    public static final KeyMapping AIM = new KeyMapping("key.gunsmod.aim", GLFW.GLFW_KEY_Z, "key.categories.gunsmod");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(RELOAD);
        e.register(AIM);
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent e) {
        e.register(GunsMod.WORKBENCH_MENU.get(), GunWorkbenchScreen::new);
        e.register(GunsMod.CUSTOMIZER_MENU.get(), GunCustomizerScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(GunsMod.GUN_BOT.get(), GunBotRenderer::new);
    }
}
